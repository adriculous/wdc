<?php return array (
  'debug' => true,
  'database' => 
  array (
    'driver' => 'mysql',
    'host' => 'localhost',
    'database' => 'adriculo_bunnda5_wsdclb',
    'username' => 'adriculo_adrime',
    'password' => 'u;mWo6)Ta~xe',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'prefix' => 'wdc',
    'strict' => false,
  ),
  'url' => 'http://wellspringdreams.club',
  'paths' => 
  array (
    'api' => 'api',
    'admin' => 'admin',
  ),
);