<script type="text/javascript">
    // inject Piwik analytics code by flagrow/flarum-ext-analytics
    var _paq = _paq || [];
    ##piwik_options##
    _paq.push(['enableLinkTracking']);
    (function () {
    var u="//##piwik_url##/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
    })();
</script>
